# Rebel Management utilities

Utility functions for querying, cleaning and processing data of Extinction Rebellion members
